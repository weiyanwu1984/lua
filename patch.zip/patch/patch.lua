require "Blue1Controller"
require "Orange1Controller"

blue1Controller = Blue1Controller:init()
orange1Controller = Orange1Controller:init()

window = UIApplication:sharedApplication():keyWindow()
window:setRootViewController(blue1Controller)

